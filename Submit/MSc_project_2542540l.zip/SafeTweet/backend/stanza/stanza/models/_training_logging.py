import logging

logger = logging.getLogger('stanza')
logger.setLevel(logging.DEBUG)