module.exports = {
    secretKey: 'secretKey'
}